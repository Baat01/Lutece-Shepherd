function tour_AdminMenu(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step1,
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-1'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step2,
		attachTo: {
				element: "li.nav-item:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-2'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step3,
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSITEHeader");
				x.click();
				cloned = x.cloneNode(true);
				path = x.parentNode;
				x.remove();
				path.appendChild(cloned);
				resolve();
			});
		},
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(1) > div > div > div > a:nth-child(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-3'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step4,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(1) > div > div > div > a:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-4'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step5,
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSITEHeader");
				x.click();
				resolve();
			});
		},
		attachTo: {
				element: "li.nav-item:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-5'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step6,
		attachTo: {
				element: "li.nav-item:nth-of-type(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-6'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step7,
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelMANAGERSHeader");
				x.click();
				cloned = x.cloneNode(true);
				path = x.parentNode;
				x.remove();
				path.appendChild(cloned);
				resolve();
			});
		},
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-7'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step8,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-8'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step9,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-9'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step10,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-10'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step11,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(5)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-11'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step12,
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelMANAGERSHeader");
				x.click();
				resolve();
			});
		},
		attachTo: {
				element: "li.nav-item:nth-of-type(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-12'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step13,
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSTYLEHeader");
				x.click();
				cloned = x.cloneNode(true);
				path = x.parentNode;
				x.remove();
				path.appendChild(cloned);
				resolve();
			});
		},
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(4) > div > div > div > a:nth-child(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-13'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step14,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(4) > div > div > div > a:nth-child(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-14'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step15,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(4) > div > div > div > a:nth-child(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-15'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step16,
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSTYLEHeader");
				x.click();
				resolve();
			});
		},
		attachTo: {
				element: "li.nav-item:nth-of-type(5)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-16'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step17,
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSYSTEMHeader");
				x.click();
				cloned = x.cloneNode(true);
				path = x.parentNode;
				x.remove();
				path.appendChild(cloned);
				resolve();
			});
		},
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-17'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step18,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-18'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step19,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-19'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step20,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-20'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step21,
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(5)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-21'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step22,
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSYSTEMHeader");
				x.click();
				resolve();
			});
		},
		attachTo: {
				element: ".lutece-aside-brand:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-22'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step23,
		attachTo: {
				element: "div.nav-item:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-23'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step24,
		attachTo: {
				element: "div.nav-item:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-24'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step25,
		attachTo: {
				element: "div.nav-item:nth-of-type(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-25'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step26,
		attachTo: {
				element: "div.card:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-26'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step27,
		attachTo: {
				element: "div.card:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-27'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step28,
		attachTo: {
				element: "div.card-primary",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-28'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step29,
		attachTo: {
				element: ".btn-sm:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-29'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step30,
		attachTo: {
				element: "a.btn-success",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-30'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step31,
		attachTo: {
				element: "a.btn.btn-sm.btn-primary",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-31'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step32,
		attachTo: {
				element: ".btn-sm:nth-of-type(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-32'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: AdminMenu_step33,
		attachTo: {
				element: ".btn-sm:nth-of-type(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-33'
	});
	tour.start();
}