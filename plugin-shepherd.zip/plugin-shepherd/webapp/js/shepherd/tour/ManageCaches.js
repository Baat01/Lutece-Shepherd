function tour_ManageCaches(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManageCaches',
		text: ManageCaches_step1,
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageCaches-step-1'
	});
	tour.addStep({
		title: 'ManageCaches',
		text: ManageCaches_step2,
		attachTo: {
				element: ".btn-danger:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageCaches-step-2'
	});
	tour.addStep({
		title: 'ManageCaches',
		text: ManageCaches_step3,
		attachTo: {
				element: ".btn-primary:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageCaches-step-3'
	});
	tour.addStep({
		title: 'ManageCaches',
		text: ManageCaches_step4,
		attachTo: {
				element: "#btn-cache-0",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageCaches-step-4'
	});
	tour.addStep({
		title: 'ManageCaches',
		text: ManageCaches_step5,
		attachTo: {
				element: "form.d-inline-flex.align-middle:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageCaches-step-5'
	});
	tour.addStep({
		title: 'ManageCaches',
		text: ManageCaches_step6,
		attachTo: {
				element: "form.d-inline-flex.align-middle:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageCaches-step-6'
	});
	tour.start();
}