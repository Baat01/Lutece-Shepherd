function tour_AdminSite(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'AdminSite',
		text: AdminSite_step1,
		attachTo: {
				element: ".btn-group:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminSite-step-1'
	});
	tour.addStep({
		title: 'AdminSite',
		text: AdminSite_step2,
		attachTo: {
				element: ".btn-group:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminSite-step-2'
	});
	tour.addStep({
		title: 'AdminSite',
		text: AdminSite_step3,
		attachTo: {
				element: ".btn-group:nth-of-type(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminSite-step-3'
	});
	tour.addStep({
		title: 'AdminSite',
		text: AdminSite_step4,
		attachTo: {
				element: ".btn-group:nth-of-type(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminSite-step-4'
	});
	tour.addStep({
		title: 'AdminSite',
		text: AdminSite_step5,
		attachTo: {
				element: ".btn-group:nth-of-type(5)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminSite-step-5'
	});
	tour.addStep({
		title: 'AdminSite',
		text: AdminSite_step6,
		attachTo: {
				element: ".btn-group:nth-of-type(6)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminSite-step-6'
	});
	tour.addStep({
		title: 'AdminSite',
		text: AdminSite_step7,
		attachTo: {
				element: ".btn-group:nth-of-type(7)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminSite-step-7'
	});
	tour.start();
}