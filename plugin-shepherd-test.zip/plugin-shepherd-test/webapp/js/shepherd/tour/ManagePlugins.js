function tour_ManagePlugins(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManagePlugins',
		text: "#i18n{shepherd-test.plugin.shepherd.ManagePlugins.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagePlugins-step-1'
	});
	tour.addStep({
		title: 'ManagePlugins',
		text: "#i18n{shepherd-test.plugin.shepherd.ManagePlugins.step2}",
		attachTo: {
				element: ".d-inline-flex.align-middle",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagePlugins-step-2'
	});
	tour.addStep({
		title: 'ManagePlugins',
		text: "#i18n{shepherd-test.plugin.shepherd.ManagePlugins.step3}",
		attachTo: {
				element: "#btn-plugin-1",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagePlugins-step-3'
	});
	tour.start();
}