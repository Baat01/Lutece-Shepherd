function tour_AssignRole(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'AssignRole',
		text: "#i18n{shepherd-test.plugin.shepherd.AssignRole.step1}",
		attachTo: {
				element: "div.col-sm-12:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AssignRole-step-1'
	});
	tour.addStep({
		title: 'AssignRole',
		text: "#i18n{shepherd-test.plugin.shepherd.AssignRole.step2}",
		attachTo: {
				element: "div.col-sm-12:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AssignRole-step-2'
	});
	tour.addStep({
		title: 'AssignRole',
		text: "#i18n{shepherd-test.plugin.shepherd.AssignRole.step3}",
		attachTo: {
				element: "#item-navigator",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AssignRole-step-3'
	});
	tour.start();
}