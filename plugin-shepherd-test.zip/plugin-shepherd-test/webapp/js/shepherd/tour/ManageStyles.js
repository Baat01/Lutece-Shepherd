function tour_ManageStyles(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManageStyles',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageStyles.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageStyles-step-1'
	});
	tour.addStep({
		title: 'ManageStyles',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageStyles.step2}",
		attachTo: {
				element: "#btn-style-create",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageStyles-step-2'
	});
	tour.addStep({
		title: 'ManageStyles',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageStyles.step3}",
		attachTo: {
				element: "#btn-style-modify-3",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageStyles-step-3'
	});
	tour.addStep({
		title: 'ManageStyles',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageStyles.step4}",
		attachTo: {
				element: ".btn-danger",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageStyles-step-4'
	});
	tour.start();
}