function tour_RoleDescription(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'RoleDescription',
		text: "#i18n{shepherd-test.plugin.shepherd.RoleDescription.step1}",
		attachTo: {
				element: ".input-group",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'RoleDescription-step-1'
	});
	tour.addStep({
		title: 'RoleDescription',
		text: "#i18n{shepherd-test.plugin.shepherd.RoleDescription.step2}",
		attachTo: {
				element: "#btn-edit-role",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'RoleDescription-step-2'
	});
	tour.addStep({
		title: 'RoleDescription',
		text: "#i18n{shepherd-test.plugin.shepherd.RoleDescription.step3}",
		attachTo: {
				element: ".btn-danger",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'RoleDescription-step-3'
	});
	tour.start();
}