function tour_AdminMenu(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-1'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step2}",
		attachTo: {
				element: "li.nav-item:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-2'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step3}",
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSITEHeader");
				x.click();
				cloned = x.cloneNode(true);
				path = x.parentNode;
				x.remove();
				path.appendChild(cloned);
				resolve();
			});
		},
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(1) > div > div > div > a:nth-child(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-3'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step4}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(1) > div > div > div > a:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-4'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step5}",
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSITEHeader");
				x.click();
				resolve();
			});
		},
		attachTo: {
				element: "li.nav-item:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-5'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step6}",
		attachTo: {
				element: "li.nav-item:nth-of-type(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-6'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step7}",
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelMANAGERSHeader");
				x.click();
				cloned = x.cloneNode(true);
				path = x.parentNode;
				x.remove();
				path.appendChild(cloned);
				resolve();
			});
		},
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-7'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step8}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-8'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step9}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-9'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step10}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-10'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step11}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(3) > div > div > div > a:nth-child(5)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-11'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step12}",
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelMANAGERSHeader");
				x.click();
				resolve();
			});
		},
		attachTo: {
				element: "li.nav-item:nth-of-type(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-12'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step13}",
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSTYLEHeader");
				x.click();
				cloned = x.cloneNode(true);
				path = x.parentNode;
				x.remove();
				path.appendChild(cloned);
				resolve();
			});
		},
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(4) > div > div > div > a:nth-child(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-13'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step14}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(4) > div > div > div > a:nth-child(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-14'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step15}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(4) > div > div > div > a:nth-child(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-15'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step16}",
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSTYLEHeader");
				x.click();
				resolve();
			});
		},
		attachTo: {
				element: "li.nav-item:nth-of-type(5)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-16'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step17}",
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSYSTEMHeader");
				x.click();
				cloned = x.cloneNode(true);
				path = x.parentNode;
				x.remove();
				path.appendChild(cloned);
				resolve();
			});
		},
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-17'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step18}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-18'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step19}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-19'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step20}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-20'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step21}",
		attachTo: {
				element: "#navbar-menu > ul > li:nth-child(5) > div > div > div > a:nth-child(5)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-21'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step22}",
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#dLabelSYSTEMHeader");
				x.click();
				resolve();
			});
		},
		attachTo: {
				element: ".lutece-aside-brand:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-22'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step23}",
		attachTo: {
				element: "div.nav-item:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-23'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step24}",
		attachTo: {
				element: "div.nav-item:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-24'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step25}",
		attachTo: {
				element: "div.nav-item:nth-of-type(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-25'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step26}",
		attachTo: {
				element: "div.card:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-26'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step27}",
		attachTo: {
				element: "div.card:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-27'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step28}",
		attachTo: {
				element: "div.card-primary",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-28'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step29}",
		attachTo: {
				element: ".btn-sm:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-29'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step30}",
		attachTo: {
				element: "a.btn-success",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-30'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step31}",
		attachTo: {
				element: "a.btn.btn-sm.btn-primary",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-31'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step32}",
		attachTo: {
				element: ".btn-sm:nth-of-type(3)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-32'
	});
	tour.addStep({
		title: 'AdminMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.AdminMenu.step33}",
		attachTo: {
				element: ".btn-sm:nth-of-type(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'AdminMenu-step-33'
	});
	tour.start();
}