function tour_ManageSearchIndexation(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManageSearchIndexation',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageSearchIndexation.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageSearchIndexation-step-1'
	});
	tour.addStep({
		title: 'ManageSearchIndexation',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageSearchIndexation.step2}",
		attachTo: {
				element: "#pageHeaderTools",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageSearchIndexation-step-2'
	});
	tour.start();
}