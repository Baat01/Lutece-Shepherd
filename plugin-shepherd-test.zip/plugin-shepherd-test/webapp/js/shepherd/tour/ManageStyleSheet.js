function tour_ManageStyleSheet(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManageStyleSheet',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageStyleSheet.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageStyleSheet-step-1'
	});
	tour.addStep({
		title: 'ManageStyleSheet',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageStyleSheet.step2}",
		attachTo: {
				element: ".d-inline-flex",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageStyleSheet-step-2'
	});
	tour.addStep({
		title: 'ManageStyleSheet',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageStyleSheet.step3}",
		attachTo: {
				element: "#btn-stylesheet-create",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageStyleSheet-step-3'
	});
	tour.addStep({
		title: 'ManageStyleSheet',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageStyleSheet.step4}",
		attachTo: {
				element: "#btn-stylesheet-215",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageStyleSheet-step-4'
	});
	tour.start();
}