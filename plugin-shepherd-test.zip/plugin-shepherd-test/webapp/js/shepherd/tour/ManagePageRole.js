function tour_ManagePageRole(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManagePageRole',
		text: "#i18n{shepherd-test.plugin.shepherd.ManagePageRole.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagePageRole-step-1'
	});
	tour.addStep({
		title: 'ManagePageRole',
		text: "#i18n{shepherd-test.plugin.shepherd.ManagePageRole.step2}",
		attachTo: {
				element: "a.btn:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagePageRole-step-2'
	});
	tour.addStep({
		title: 'ManagePageRole',
		text: "#i18n{shepherd-test.plugin.shepherd.ManagePageRole.step3}",
		attachTo: {
				element: "a.btn:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagePageRole-step-3'
	});
	tour.addStep({
		title: 'ManagePageRole',
		text: "#i18n{shepherd-test.plugin.shepherd.ManagePageRole.step4}",
		attachTo: {
				element: "#btn-template-modify-page-role",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagePageRole-step-4'
	});
	tour.addStep({
		title: 'ManagePageRole',
		text: "#i18n{shepherd-test.plugin.shepherd.ManagePageRole.step5}",
		attachTo: {
				element: "a.btn.btn-danger",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagePageRole-step-5'
	});
	tour.start();
}