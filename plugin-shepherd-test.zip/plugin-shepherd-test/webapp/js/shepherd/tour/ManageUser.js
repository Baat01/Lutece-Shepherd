function tour_ManageUser(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-1'
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step2}",
		attachTo: {
				element: ".btn-primary:nth-of-type(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-2'
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step3}",
		attachTo: {
				element: ".btn-primary:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-3'
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step4}",
		beforeShowPromise: function() {
			return new Promise(function(resolve) {
				x = document.querySelector("#portlet-type");
				x.click();
				cloned = x.cloneNode(true);
				path = x.parentNode;
				x.remove();
				path.appendChild(cloned);
				resolve();
			});
		},
		attachTo: {
				element: "li:nth-of-type(6)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-4'
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step5}",
		attachTo: {
				element: "li:nth-of-type(7)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-5'
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step6}",
		attachTo: {
				element: "li:nth-of-type(8)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-6'
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step7}",
		attachTo: {
				element: "li:nth-of-type(9)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-7'
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step8}",
		attachTo: {
				element: "li:nth-of-type(10)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-8'
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step9}",
		attachTo: {
				element: "li:nth-of-type(11)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-9'
	});
	tour.addStep({
		title: 'ManageUser',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageUser.step10}",
		attachTo: {
				element: "li:nth-of-type(12)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageUser-step-10'
	});
	tour.start();
}