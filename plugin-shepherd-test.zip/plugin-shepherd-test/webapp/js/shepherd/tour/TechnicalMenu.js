function tour_TechnicalMenu(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'TechnicalMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.TechnicalMenu.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'TechnicalMenu-step-1'
	});
	tour.addStep({
		title: 'TechnicalMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.TechnicalMenu.step2}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'TechnicalMenu-step-2'
	});
	tour.addStep({
		title: 'TechnicalMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.TechnicalMenu.step3}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'TechnicalMenu-step-3'
	});
	tour.addStep({
		title: 'TechnicalMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.TechnicalMenu.step4}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'TechnicalMenu-step-4'
	});
	tour.addStep({
		title: 'TechnicalMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.TechnicalMenu.step5}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'TechnicalMenu-step-5'
	});
	tour.addStep({
		title: 'TechnicalMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.TechnicalMenu.step6}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'TechnicalMenu-step-6'
	});
	tour.addStep({
		title: 'TechnicalMenu',
		text: "#i18n{shepherd-test.plugin.shepherd.TechnicalMenu.step7}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'TechnicalMenu-step-7'
	});
	tour.start();
}