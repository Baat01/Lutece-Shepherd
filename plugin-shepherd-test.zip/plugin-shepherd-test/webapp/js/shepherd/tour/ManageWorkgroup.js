function tour_ManageWorkgroup(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManageWorkgroup',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageWorkgroup.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageWorkgroup-step-1'
	});
	tour.addStep({
		title: 'ManageWorkgroup',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageWorkgroup.step2}",
		attachTo: {
				element: "#btn-template-create-role",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageWorkgroup-step-2'
	});
	tour.addStep({
		title: 'ManageWorkgroup',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageWorkgroup.step3}",
		attachTo: {
				element: "#btn-template-modify-workgroup",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageWorkgroup-step-3'
	});
	tour.addStep({
		title: 'ManageWorkgroup',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageWorkgroup.step4}",
		attachTo: {
				element: "#lutece-layout-wrapper > section > div > main > div > div > div.table-responsive.bg-white > table > tbody > tr > td:nth-child(3) > a:nth-child(4)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageWorkgroup-step-4'
	});
	tour.addStep({
		title: 'ManageWorkgroup',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageWorkgroup.step5}",
		attachTo: {
				element: ".btn-danger",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageWorkgroup-step-5'
	});
	tour.start();
}