function tour_ManageRoles(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManageRoles',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageRoles.step1}",
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageRoles-step-1'
	});
	tour.addStep({
		title: 'ManageRoles',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageRoles.step2}",
		attachTo: {
				element: "#btn-template-create-role",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageRoles-step-2'
	});
	tour.addStep({
		title: 'ManageRoles',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageRoles.step3}",
		attachTo: {
				element: "#lutece-layout-wrapper > section > div > main > div > div > div.table-responsive.bg-white > table > tbody > tr:nth-child(1) > td:nth-child(3) > a:nth-child(1)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageRoles-step-3'
	});
	tour.addStep({
		title: 'ManageRoles',
		text: "#i18n{shepherd-test.plugin.shepherd.ManageRoles.step4}",
		attachTo: {
				element: ".btn-primary:nth-of-type(2)",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageRoles-step-4'
	});
	tour.start();
}