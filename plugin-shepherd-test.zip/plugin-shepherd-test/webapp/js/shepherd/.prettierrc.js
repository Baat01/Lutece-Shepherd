'use strict';

module.exports = {
  arrowParens: 'always',
  trailingComma: 'none',
  singleQuote: true
};
