Put your images in this directory and then you can insert them in your xdoc with the code :  <img src="images/myimage.png" />

