function tour_ManageProperties(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManageProperties',
		text: ManageProperties_step1,
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManageProperties-step-1'
	});
	tour.start();
}