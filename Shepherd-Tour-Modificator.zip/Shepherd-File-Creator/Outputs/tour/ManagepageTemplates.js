function tour_ManagepageTemplates(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'ManagepageTemplates',
		text: ManagepageTemplates_step1,
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagepageTemplates-step-1'
	});
	tour.addStep({
		title: 'ManagepageTemplates',
		text: ManagepageTemplates_step2,
		attachTo: {
				element: "#btn-template-create",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagepageTemplates-step-2'
	});
	tour.addStep({
		title: 'ManagepageTemplates',
		text: ManagepageTemplates_step3,
		attachTo: {
				element: "#btn-template-1",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagepageTemplates-step-3'
	});
	tour.addStep({
		title: 'ManagepageTemplates',
		text: ManagepageTemplates_step4,
		attachTo: {
				element: ".btn-danger",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'ManagepageTemplates-step-4'
	});
	tour.start();
}