function tour_Portal(){
	const tour = new Shepherd.Tour({
		useModalOverlay: true,
		defaultStepOptions: {
			classes: 'shadow-md bg-purple-dark',
			scrollTo: true
		}
	});
	tour.addStep({
		title: 'Portal',
		text: Portal_step1,
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'Portal-step-1'
	});
	tour.addStep({
		title: 'Portal',
		text: Portal_step2,
		attachTo: {
				element: "#navbarSupportedContent",
				on: "bottom"
			},
		buttons: [
		{
			action() {
				return this.back();
			},
			classes: 'shepherd-button-secondary',
			text: 'Back'
		},
		{
			action() {
				return this.next();
			},
			text: 'Next'
		}
		],
		cancelIcon:
		{
			enabled: 'true'
		},
		id: 'Portal-step-2'
	});
	tour.start();
}