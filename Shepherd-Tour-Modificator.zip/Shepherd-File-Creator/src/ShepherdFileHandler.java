import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class ShepherdFileHandler {
	
	private static final String folderInputPath = "./Inputs";
	private static final String folderOutputPath = "./Outputs/tour";
	private static final String folderOutputLanguagePath = "./Outputs/language";
	
	public static void main(String[] args)
	{
		// Cleaning outputs (tour&language) folder
        Path folderOutput = Paths.get(folderOutputPath);
        Path folderLanguageOutput = Paths.get(folderOutputLanguagePath);

        // Open a directory stream for the folder
        DirectoryStream<Path> dirStream;
        DirectoryStream<Path> dirStreamLanguage;
		try {
			dirStream = Files.newDirectoryStream(folderOutput);
			dirStreamLanguage = Files.newDirectoryStream(folderLanguageOutput);
			
			for (Path file : dirStream) {
	        	// Delete the files in the directory
	        	if (Files.isRegularFile(file)) {
	            	 Files.delete(file);
	        	}
	        }
			
			for (Path fileLanguage : dirStreamLanguage) {
	        	// Delete the files in the directory
	        	if (Files.isRegularFile(fileLanguage)) {
	            	 Files.delete(fileLanguage);
	        	}
	        }
			
				
		} catch (IOException e) {
			e.printStackTrace();
		}
		// Creating a file object for the folder path
        File folder = new File(folderInputPath);

        // If the folder exist, apply the function for each files
        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();
            for (File file : files) {
                if (file.isFile()) {
                	ReadShepherdTXTFile(file);
                }
            }
        } else {
            System.out.println("Specified folder doesn't exist or isn't a folder.");
        }
		//ReadShepherdTXTFile("input.txt");
	}
	
	public static void writeShepherdJSFile(ArrayList<String> element,ArrayList<String> text,String name) {
		try {
			BufferedWriter writer = new BufferedWriter(new FileWriter(new File(folderOutputPath,name+".js")));
			BufferedWriter languageDev = new BufferedWriter(new FileWriter(new File(folderOutputLanguagePath,"dev.js"),true));
			BufferedWriter languageDefault = new BufferedWriter(new FileWriter(new File(folderOutputLanguagePath,"default.js"),true));
			//the dev.js file is a language file used to see which variable to change for the tour during it
			//the default.js file is a language file used by default if there's no other available option
			//Create the file associated with the page that we're doing, and create the 'header' of the jsfile
			writer.write("function tour_"+name+"(){");
			writer.write("\n	const tour = new Shepherd.Tour({");
			writer.write("\n		useModalOverlay: true,");
			writer.write("\n		defaultStepOptions: {");
			writer.write("\n			classes: 'shadow-md bg-purple-dark',");
			writer.write("\n			scrollTo: true");
			writer.write("\n		}");
			writer.write("\n	});");
			for(int i=0;i<element.size();i++) {
				//Create each step given at the start of the function
				writer.write("\n	tour.addStep({");
				//Create the title of the step, taken from the given name
				writer.write("\n		title: '"+name+"',");
				//Create the text from the text variable
				writer.write("\n		text: "+name+"_step"+(i+1)+",");
				languageDev.write("var "+name+"_step"+(i+1)+"=\""+name+"_step"+(i+1)+"\";\n");
				languageDefault.write("var "+name+"_step"+(i+1)+"=\""+text.get(i)+"\";\n");
				if(! element.get(i).equals("none")) {
					//We don't put attachTo property in case of centered bubble (element = none)
					String elementSelector = element.get(i);
					if(element.get(i).contains("_")) {
						String tabEl[] = element.get(i).split("_");
						elementSelector = tabEl[0];
						writer.write("\n		beforeShowPromise: function() {");	
						writer.write("\n			return new Promise(function(resolve) {");
						writer.write("\n				x = document."+tabEl[2]+";");
						writer.write("\n				x.click();");
						if(tabEl[1].equals("start")) {
							writer.write("\n				cloned = x.cloneNode(true);");
							writer.write("\n				path = x.parentNode;");
							writer.write("\n				x.remove();");
							writer.write("\n				path.appendChild(cloned);");
						}
						writer.write("\n				resolve();");
						writer.write("\n			});");
						writer.write("\n		},");
					}
					writer.write("\n		attachTo: {");
					writer.write("\n				element: \""+elementSelector+"\",");
					writer.write("\n				on: \"bottom\"");
					writer.write("\n			},");
				}
				//Create the classic button to advance and go back (can be removed later to optimise the file)
				writer.write("\n		buttons: [");
				writer.write("\n		{");
				writer.write("\n			action() {");
				writer.write("\n				return this.back();");
				writer.write("\n			},");
				writer.write("\n			classes: 'shepherd-button-secondary',");
				writer.write("\n			text: 'Back'");
				writer.write("\n		},");
				writer.write("\n		{");
				writer.write("\n			action() {");
				writer.write("\n				return this.next();");
				writer.write("\n			},");
				writer.write("\n			text: 'Next'");
				writer.write("\n		}");
				writer.write("\n		],");
				writer.write("\n		cancelIcon:");
				writer.write("\n		{");
				writer.write("\n			enabled: 'true'");
				writer.write("\n		},");
				writer.write("\n		id: '"+name+"-step-"+(i+1)+"'");
				writer.write("\n	});");
			}
			//Create the "footer" of the jsfile
			writer.write("\n	tour.start();");
			writer.write("\n}");
			writer.close();
			languageDev.close();
			languageDefault.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void ReadShepherdTXTFile(File TXTFile) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(TXTFile));
			String line = new String();
			String name = new String("");
			ArrayList<String> element = new ArrayList<String>();
			ArrayList<String> text = new ArrayList<String>();
			boolean ligneActTexte = true;
			//Read all the line of all the given file
			while((line = reader.readLine()) != null){
				//if the line is the keyword for the next file, create the actual file and reset variables value 
				if(line.equals("NextFile")) {
					writeShepherdJSFile(element,text,name);
					name = "";
					element.clear();
					text.clear();
					ligneActTexte = true;
					continue;
				}
				if (name.equals("")) {
					name = line;
					continue;
				}
				if (ligneActTexte == true) {
					text.add(line);
					ligneActTexte = false;
				}
				else {
					element.add(line);
					ligneActTexte = true;
				}	
			}
			//if there's still stuff in the variables, create the final file before closing the reader
			if(!name.equals(""))
				writeShepherdJSFile(element,text,name);
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
